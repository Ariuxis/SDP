create procedure createPostgraduate(IN pgrad_name        text, IN pgrad_credit tinyint, IN pgrad_tuition decimal,
                                    IN pgrad_duration    tinyint, IN pgrad_aspirant text, IN pgrad_student text,
                                    IN pgrad_inscription mediumint, IN pgrad_plan text)
  begin
  replace into Postgraduate(pgradName, pgradCredit, pgradTuition,
                            pgradDuration, pgradAspirant, pgradStudent,
                            pgradInscription, pgradPlan)
                            values (pgrad_name, pgrad_credit, pgrad_tuition,
                                    pgrad_duration, pgrad_aspirant, pgrad_student,
                                    pgrad_inscription, pgrad_plan);
  commit;
end;

